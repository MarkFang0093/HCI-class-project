#pragma once

#ifdef __cplusplus
extern "C"
{
#endif

int free_ram1();
int free_ram2();
int free_ram3();

#ifdef  __cplusplus
}
#endif

