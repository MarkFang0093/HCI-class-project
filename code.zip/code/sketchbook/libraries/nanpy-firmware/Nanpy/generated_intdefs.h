
// Generated file, do not edit!

#define LONGEST_STRING_IN_INTDEFS_H  20


#ifdef NUM_DIGITAL_PINS
    DEFINE(NUM_DIGITAL_PINS)
#endif

#ifdef RAMSTART
    DEFINE(RAMSTART)
#endif

#ifdef RAMEND
    DEFINE(RAMEND)
#endif

#ifdef XRAMEND
    DEFINE(XRAMEND)
#endif

#ifdef E2END
    DEFINE(E2END)
#endif

#ifdef FLASHEND
    DEFINE(FLASHEND)
#endif

#ifdef SPM_PAGESIZE
    DEFINE(SPM_PAGESIZE)
#endif

#ifdef E2PAGESIZE
    DEFINE(E2PAGESIZE)
#endif

#ifdef F_CPU
    DEFINE(F_CPU)
#endif

#ifdef ARDUINO
    DEFINE(ARDUINO)
#endif

#ifdef __AVR_LIBC_DATE_
    DEFINE(__AVR_LIBC_DATE_)
#endif

#ifdef __AVR_LIBC_VERSION__
    DEFINE(__AVR_LIBC_VERSION__)
#endif

#ifdef IRAM0_ADDR
    DEFINE(IRAM0_ADDR)
#endif

#ifdef IRAM0_SIZE
    DEFINE(IRAM0_SIZE)
#endif

#ifdef IRAM1_ADDR
    DEFINE(IRAM1_ADDR)
#endif

#ifdef IRAM1_SIZE
    DEFINE(IRAM1_SIZE)
#endif
