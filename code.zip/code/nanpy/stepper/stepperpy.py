from nanpy import (ArduinoApi, SerialManager)
from time import sleep


stepper1= 5
stepper2= 6
stepper3= 7
stepper4= 8
ledState = False
buttonState = 0

try:
    connection = SerialManager()
    a = ArduinoApi(connection = connection)
except:
    print("failed to connect Arduino")

# Setup pins
a.pinMode(ledPin, a.OUTPUT)
a.pinMode(bottonPin, a.INPUT)

try:
    while True:
        
    
    
